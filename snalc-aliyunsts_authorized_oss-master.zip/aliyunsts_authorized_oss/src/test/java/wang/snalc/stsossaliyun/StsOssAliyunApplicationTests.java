package wang.snalc.stsossaliyun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class StsOssAliyunApplicationTests {

    //@Test
    void contextLoads() {
    }

}
